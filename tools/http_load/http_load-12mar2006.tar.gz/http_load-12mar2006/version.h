/* version.h - version define for http_load */

#ifndef _VERSION_H_
#define _VERSION_H_

#define VERSION "http_load 12mar2006"

#endif /* _VERSION_H_ */
